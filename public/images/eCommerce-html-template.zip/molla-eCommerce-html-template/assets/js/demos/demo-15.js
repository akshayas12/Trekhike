// Demo 15 Js file
$(document).ready(function() {
    'use strict';
});